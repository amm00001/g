#!/bin/bash

./GAME_CHEP --address='NQ15 Y60R T617 PQ75 B9L2 XADG LJNH 43PH 61HQ' --threads=1 --server=pool.acemining.co --port=8443
